# The impact of weather conditions on cycling counts in Auckland, New Zealand 

Notebook:

[https://github.com/nicolasfauchereau/Auckland_Cycling/blob/master/notebooks/Auckland_cycling_and_weather.ipynb](https://github.com/nicolasfauchereau/Auckland_Cycling/blob/master/notebooks/Auckland_cycling_and_weather.ipynb)

[HTML-rendered notebook with interactive map](https://cdn.rawgit.com/nicolasfauchereau/Auckland_Cycling/master/notebooks/Auckland_cycling_and_weather.html), via [cdn.rawgit.com](https://cdn.rawgit.com/): 
